﻿using ShopOnConsoleApp;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShopOnApp
{
    public class MainMenu
    {
        public void Main()
        {
            new ProductMain().ProductMainMenu();
            //new UserMain().Main();
        }

    }
}
