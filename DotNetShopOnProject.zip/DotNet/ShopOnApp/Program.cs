﻿using System;

namespace ShopOnApp
{
    class Program
    {
        static void Main(string[] args)
        {
            new MainMenu().Main();
        }
    }
}
