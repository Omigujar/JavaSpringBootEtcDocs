﻿using ShopOn.BusinessLayer.Utility;
using ShopOn.CommonLayer.Models;
using ShopOn.DataLayer.Contracts;
using ShopOn.DataLayer.Implementation;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShopOn.BusinessLayer.Implementation
{
    public class ProductManager
    {
        private readonly IProductRepository productRepository;

        //private ProductRepositoryInMemoryArray productRepository = new ProductRepositoryInMemoryArray();

        //private ProductRepositoryInMemoryDictionary productRepository = new ProductRepositoryInMemoryDictionary();

        public ProductManager(IProductRepository productRepository)
        {
            this.productRepository = productRepository;
        }

        public bool AddProduct(Product product, out string errMessage)
        {
            return productRepository.InsertProduct(product, out errMessage);
        }

        public Product[] GetProducts()
        {
            return productRepository.GetProducts();
        }

        public Product GetProduct(int productId)
        {
            return productRepository.GetProductById(productId);
        }

        public bool UpdateProduct(int productId)
        {
            return productRepository.UpdateProduct(productId);
        }

        public bool DeleteProduct(int productId)
        {
            return productRepository.DeleteProduct(productId);
        }

        public List<Product> SortById()
        {
            var result = this.productRepository.GetProducts();
            var sortData = result.ToList();
            sortData.Sort(new IdComparer());
            return sortData;
        }

        public List<Product> SortByPrice()
        {
            var result = this.productRepository.GetProducts();
            var sortData = result.ToList();
            sortData.Sort(new PriceComparer());
            return sortData;
        }

        public List<Product> SortByName()
        {
            var result = this.productRepository.GetProducts();
            var sortData = result.ToList();
            sortData.Sort(new NameComparer());
            return sortData;
        }
    }
}
