﻿using ShopOn.CommonLayer.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShopOn.DataLayer.Contracts
{
    public interface IProductRepository
    {
        bool InsertProduct(Product product, out string errMessage);
        Product GetProductById(int productId);
        Product[] GetProducts();
        bool UpdateProduct(int productId);
        bool DeleteProduct(int productId);

    }
}
