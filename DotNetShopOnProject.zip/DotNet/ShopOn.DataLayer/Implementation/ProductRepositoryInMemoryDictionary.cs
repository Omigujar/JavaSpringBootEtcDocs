﻿using ShopOn.CommonLayer.Models;
using ShopOn.DataLayer.Contracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShopOn.DataLayer.Implementation
{
    public class ProductRepositoryInMemoryDictionary : IProductRepository
    {
        private Dictionary<int, Product> products = new Dictionary<int, Product>();
        public bool InsertProduct(Product product, out string errMessage)
        {

            errMessage = string.Empty;
            if (product.ProductId == 0 || string.IsNullOrEmpty(product.ProductName) || product.ProductPrice == 0)
            {
                errMessage = "Invalid ProductId or ProdcutName or ProductPrice";
                return false;
            }
            products.Add(product.ProductId, product);

            return true;
        }

        public Product GetProductById(int productId)
        {
            Dictionary<int, Product>.KeyCollection keyColl = products.Keys;
            Product searchProduct = null;
            foreach (int pId in keyColl)
            {
                if (pId == productId)
                {
                    searchProduct = products[pId];

                }
            }
            return searchProduct;
        }

        public Product[] GetProducts()
        {
            //Dictionary<int, Product>.ValueCollection valueColl = products.Values;
            Product[] values = new Product[products.Count];
            products.Values.CopyTo(values, 0);
            return values;
        }

        public bool UpdateProduct(int productId)
        {
            bool isPresent = false;
            if (GetProductById(productId) != null)
            {
                isPresent = true;
            }
            return isPresent;
        }

        public bool DeleteProduct(int productId)
        {
            bool isPresent = false;
            if (GetProductById(productId) != null)
            {
                products.Remove(productId);
                isPresent = true;
            }
            return isPresent;
        }

    }
}

