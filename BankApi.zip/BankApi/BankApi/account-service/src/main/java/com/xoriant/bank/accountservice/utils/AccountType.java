package com.xoriant.bank.accountservice.utils;

public enum AccountType {

	SAVING,CURRENT;
	
}
