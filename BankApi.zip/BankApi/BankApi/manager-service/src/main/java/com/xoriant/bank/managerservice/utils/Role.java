package com.xoriant.bank.managerservice.utils;

public enum Role {
	MANAGER,CUSTOMER
}
