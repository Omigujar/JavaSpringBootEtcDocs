package com.xoriant.bank.customerservice.utils;

public enum AccountType {
CURRENT,SAVING;
}
