package com.xoriant.bank.customerservice.utils;

public enum Gender {
 MALE,FEMALE;
}
