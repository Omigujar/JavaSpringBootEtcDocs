﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace BankingApplication.WebApp.Models
{
    public class AccountCreationVM
    {
        [Display(Name = "Enter Your customerId ")]
        [Required(ErrorMessage = "customerId should not be blank!")]
        public string CustomerId { get; set; }

        [Display(Name = "Enter Your Balance ")]
        [Required(ErrorMessage = "Balance should not be blank!")]
        public double Balance { get; set; }

        [Display(Name = "Enter DOC ")]
        [Required(ErrorMessage = "Balance should not be blank!")]
        public DateTime DOC { get; set; }

        [Display(Name = "Enter Your TIN ")]
        [Required(ErrorMessage = "Balance should not be blank!")]
        public string Tin { get; set; }

        [Display(Name = "Choose Your Account Type ")]
        [Required(ErrorMessage = "Balance should not be blank!")]
        public string AccountType { get; set; }

        [Display(Name = "Enter Your IFSC ")]
        [Required(ErrorMessage = "Balance should not be blank!")]
        public string IFSC { get; set; }

    }
}
