﻿using System;

namespace BankingApplication.ConsoleApp
{
    class Program
    {
        static void Main(string[] args)
        {
            new EmployeeMain().Main();
        }
    }
}
